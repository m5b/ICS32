
def intro(): 
    print("Welcome to the user statement maker")

def get_username():
    username = input("What is your username? ")
    return username

def get_age():
    age = int(input("How old are you? "))
    if age < 18:
        print("You are too young")
        age = None
    return age

def print_msg(msg: str):
    print(msg)
