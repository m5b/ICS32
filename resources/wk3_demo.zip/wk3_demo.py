import wk3_ui

class UserA():
    def __init__(self, name=None, age=None):
        self.name = name
        self.age = age

    def _verify_age(self, age):
        pass

    def user_statement(self):
        return f"Hello, my name is {self.name}, I am {self.age}."

    def static_user_statement(name, age):
        return f"Hello, my name is {name}, I am {age}."




wk3_ui.intro()

username = wk3_ui.get_username()
age = wk3_ui.get_age()

if age != None:
    user = UserA(username, age)
    wk3_ui.print_msg(user.user_statement())


